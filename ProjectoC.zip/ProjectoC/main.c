#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define max 255
#define MAXSTR 1024

struct Person{ //Linked list node
    char personID[max];
    char name[max];
    int age;
    char address[max];
    struct Person* next;
};

//NOTE: A node can be added in three ways
/*1.at the front of the linked list
  2.after a given node
  3.at the enf of the linked list*/

void searchFunction(int n);
void sortingFunctionAscend(int arr[], int len);
void sortingFunctionDescend(int arr[], int len);
void createFile();
void writeFile();
void readFile();
void deleteFile();
void cLanguagePointers();
void push(struct Person** head_ref, char newID[], char newName[], int newAge, char newAddress[]);
void printList(struct Person* p);
void searchElement(struct Person* ps, char id[]);
void getStr(char str[],size_t len);

int main()
{
    int x = 0;
    int num[] = {1, 4, 3, 8, 90, 45, 23, 27, 78, 56, 123, 456, 12, 5};
    int length = sizeof(num) / sizeof(num[0]);
    int option = 0;
    int sair = 0;
    int nPersons = 0;
    int opt = 0;
    int exit = 0;
    char personName[max];
    int personAge;
    char personAddress[max];
    int nPeople = 0;
    char pID[max];
    char searchID[max];
    int b = 0;
    char castStr[max];

    struct Person* head = NULL; //Start with the empty list

    // ******************* Algorithms *****************************************

    //Linear Search


    printf("Numero a procurar: \n");
    scanf("%d", &x);
    searchFunction(x);

    //Ascending Sorting
    printf("\nLength array sorted:%d", length);
    sortingFunctionAscend(num, length);

    //Descendente Sorting
    sortingFunctionDescend(num, length);

    //********************************** Ficheiros (tutorialspoint e portugal a programar) //Ver link: https://www.codegrepper.com/code-examples/c/how+to+delete+data+and+add+from+file+in+c+language
    //Criar Ficheiro logo que inicia o programa a primeira vez
    createFile();

    ///////////////////// Pointers ////////////////////////////////////
    cLanguagePointers();

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    printf("\n\n ****** Linked Lists *******\n\n");

    //Cada n� da lista ligada:Value and pointer to the next element
    //Linked listed: dinamica, ao contario dos arrays

    //N�o se pode aceder a cada elemento
    //da lista ligada de forma aleat�ria como
    //nos arrays, por exemplo array[5]

    //As listas ligadas ocupam mais mem�ria que
    //os arrays pois aramazenam um valor e um
    //apontador para o pr�ximo elemento.

    //Conforme os projectos temos de ver se �
    // arrays ou linked lists, um n�o � melhor
    //que o outro, depende dos projectos

    do{
            printf("\n1.Inserir pessoa.\n");
            printf("2.Procurar pessoa.\n");
            printf("3.Editar pessoa.\n");
            printf("4.Listar pessoas da Lista.\n");
            printf("5.Eliminar pessoa.\n");
            printf("6.Eliminar Lista de Pessoas.\n");
            printf("0.Sair\n");
            printf("Introduza Opcao: \n");
            scanf("%d", &opt);

            while(opt < 0 || opt > 6){
                printf("\nOpcao ERRADA!!!!\n");
                printf("Introduza nova Opcao: \n");
                scanf("%d", &opt);

            }

            switch(opt){
                case 1:
                    printf("\nNumero de pessoas a inserir:");
                    scanf("%d", &nPeople);

                    for(int k = 0; k < nPeople; k++){
                        b += 1;
                        sprintf(castStr,"%d",b);
                        strcpy(pID, "A");
                        strcat(pID, castStr);
                        printf("\nPerson ID: %s\n", pID);
                        printf("\nPerson Name: \n"); //ERRO: NOTA: Não lê as strings
                        scanf("%[^\n]s", personName);
                        while((getchar()) != '\n');
                        printf("Person Age: \n");
                        scanf("%d", &personAge);
                        printf("Person Address: \n");
                        scanf("%[^\n]s", personAddress);
                        while((getchar()) != '\n');
                        push(&head, pID, personName, personAge, personAddress); //Insert at the beginning of the list
                    }
                break;
                case 2:
                    fflush(stdin);
                    printf("Person ID:\n");
                    scanf("%[^\n]s", searchID);
                    printf("\nSearch ID:%s\n",searchID);
                    searchElement(head, searchID);
                break;
                case 3:
                break;
                case 4:
                    printList(head);
                break;
                case 0:
                exit = 1;
                break;


            }

    }while(!exit);


    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    do{
            printf("\n\n*************** Registo de Clientes *******************\n\n");
            printf("\n1.Registar Cliente\n");
            printf("\n2.Listar Clientes\n");
            printf("\n3.Procurar cliente\n");//Ver como percorrer o ficheiro e encontrar um cliente pelo nome ou assim
            printf("\n4.Eliminar cliente\n"); //Apagar um cliente do ficheiro **** NOTA ****: a solu��o para isto est� num site codegrepper (tem nos marcadores)
            printf("\n5.Eliminar todos os registos de Clientes\n");//Apagar todos os clientes registados no ficheiro
            printf("\n6.Eliminar Ficheiro\n");//Eliminar o ficheiro onde est�o registados os clientes
            printf("\n7.Sair\n");
            printf("\nInserir opcao:\n\n");
            scanf("%d", &option);

            while(option < 1 || option > 7){
                printf("\nErro!!! Insira opcao valida:\n\n");
                scanf("%d", &option);
            }

            switch(option){

            case 1:
                //Escrever no ficheiro
                writeFile();
                break;
            case 2:
                //Leitura do ficheiro
                readFile();
                break;
            case 3:
                break;
            case 4:
                break;
            case 5:
                break;
            case 6: //Eliminar ficheiro
                deleteFile();
                break;
            case 7:
                sair = 1;
                break;
            }


    }while(!sair);

    return 0;
}

void searchFunction(int n){

    int numbers[] = {2, 7, 9, 45, 36, 78, 123, 456, 86};
    int range = sizeof(numbers) / sizeof(numbers[0]);

    for(int i = 0; i < range;i++){
        if(numbers[i] == n){
            printf("\nNumero:%d\n", numbers[i]);
            printf("Index:%d\n", i);
        }
    }

}

void sortingFunctionAscend(int arr[], int len){

    //Use swap
    int temp = 0;

    for(int i = 0; i < len;i++){
            for(int j = i+1; j < len; j++){
                if(arr[i] > arr[j]){
                    temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
    }

    printf("\n\nArray ordenado ascendente:\n");
    for(int k = 0; k < len ;k++){
        printf("%d\n", arr[k]);
    }
}

void sortingFunctionDescend(int arr[], int len){

    //Use swap
    int temp = 0;

    for(int i = 0; i < len; i++){
        for(int j = i+1; j < len; j++){
            if(arr[i] < arr[j]){
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }

    //Array ordenado de forma descendente
    printf("\nArray ordenado descendente:\n");

    for(int k =0;k < len; k++){
        printf("%d\n", arr[k]);
    }

}

void createFile(){ //Criar e escrever num ficheiro

    ////////////// ********** Manipula��o de Ficheiros ********************** ////////////////
    //// 1. Abrir o Ficheiro
    //// 2. Ler ou escrever no Ficheiro
    //// 3. Fechar o Ficheiro


    /// Criar e escrever num ficheiro

    FILE *fp; //iniciar apontador

    if((fp = fopen("FicheiroDados.txt", "a+")) == NULL){
        printf("\nImpossivel criar o ficheiro!!\n");
    }else{
            //fputs("Programa��o em linguagem C!\n", fp);//Esta fun��o tbem pode ser usada para escrever
    }

    fclose(fp); //Fechar um ficheiro

}

void writeFile(){

    char nome[max] = "";
    char idade[max] = "";
    int num = 0;

    FILE *fp;

    printf("\nNumero clientes a registar:\n");
    scanf("%d", &num);
    printf("\nDados do cliente:\n\n");

    for (int i = 0; i < num; i++){

            fflush(stdin);
            printf("Nome:\n"); //NOTA: A inten��o aqui era que ao ler aparecesse assim --> Nome: Ricardo Idade: 35
            fgets(nome, max, stdin);
            printf("Idade:\n");
            fgets(idade, max, stdin);//Limita o tamanho da string para 255 evitando overflow, e l� do teclado usando stdin

            if((fp = fopen("FicheiroDados.txt", "a"))==NULL){
                printf("Impossivel abrir ficheiro!!");
            }else{
                    fprintf(fp, nome);
                    fprintf(fp, idade);
                    fprintf(fp, "\n");
            }

        fclose(fp);
    }

}

void readFile(){

    FILE *fp; //iniciar apontador
    char buff[max];

    if((fp = fopen("FicheiroDados.txt", "r")) == NULL){
        printf("\nImpossivel abrir o ficheiro!!\n");
    }else{
            while(fgets(buff, max, (FILE*)fp)!=NULL){ //Leitura linha a linha do ficheiro, se tiver mais que uma linha
                printf("%s", buff);
            }

    }

    fclose(fp); //Fechar um ficheiro
}

void deleteFile(){

    int del_file = remove("FicheiroDados.txt");

    if(!del_file){
        printf("\nO ficheiro foi eliminado com sucesso!\n");
    }else{
        printf("\nERRO!!O ficheiro n�o foi eliminado!!!!\n");
    }
}

void cLanguagePointers(){ //Pointers use with arrays, functions and structures (freecodecamp)

int digit = 42;

printf("\nThe address of digit: %d.\n", &digit); //NOTA: o warning do %d est� resolvido mais abaixo usando %p
printf("\nThe value of digit = %d.\n", *(&digit));

printf("\nUsing pointers variables:\n");

int *addressOfDigit = &digit; //O tipo da vari�vel apontador tem de ser do tipo da vari�vel para o qual aponta (neste caso int)

//A pointer variable is a special variable in the sense that it is used to store an address of another variable

printf("\nThe address of digit: %d.\n", addressOfDigit);//NOTA: o warning do %d est� resolvido mais abaixo usando %p
printf("\nThe value of digit = %d.\n", *(addressOfDigit));

int num = 5;
int *pointer = &num;

printf("\nAddress --> Hexadecimal: %%p = %p", pointer);
printf("\nAddress --> Octal: %%o = %o", pointer);
printf("\nAddress --> Integer: %%d = %d", pointer);

//3. Some Special Pointers

//The Wild Pointer
printf("\n\n*************** Wild Pointer ***************\n\n");
char *alphabetAddress; //apontador n�o inicializado ou "selvagem" (Wild Pointer)

printf("\n\nalphabetAddress sem atribuicao de valor: %p", alphabetAddress); //O valor armazenado por uma vari�vel apontador n�o
//inicializada � lixo (posi��o de mem�ria n�o definida/aleat�ria)

char alphabet = "a";

alphabetAddress = &alphabet; //Now, not a wild pointer

///NOTA: apontadores n�o inicializados s�o chamados de Wild Pointers ("apontadores selvagens");

///// Null Pointer /////////////////////////////////

printf("\n\nNull Pointer!!!!!\n\n");

///// IMPORTANT NOTE: A null pointer points at nothing, or at a memory address that users can not access.


///// NOTE: To make sure that we do not have a wild pointer, we can initialize a pointer with a NULL value, making it a null pointer


char *varAddress = NULL;
printf("varAddress --> NULL pointer: %p", varAddress);

printf("\n\n************** Void Pointer *****************\n\n");

void *pointerVar = NULL; //Since they are very general in nature, they are also known as Generic Pointers.

int varNumber = 54;

char letter = 'A';

pointerVar = &varNumber;

//printf("\n\nThe value of number is: %d", *pointerVar); //Compilation error (os apontadores void n�o permitem fazer isto, � preciso fazer type casting)

printf("\n\nThe value of number is (Correct way): %d", *((int*)pointerVar));

pointerVar = &letter;

//printf("\nThe value of letter is: ", *pointerVar);//Compilation error (os apontadores void n�o permitem fazer isto, � preciso fazer type casting)
printf("\nThe value of letter is (Correct way): %c\n", *((char*)pointerVar));

///Note: Similarly, void pointers need to be typecasted for performing arithmetic operations.

///////////////// Dangling Pointer /////////////////////////////////////////////////////

int *ptr;
ptr = (int*)malloc(sizeof(int)); //Aloca��o de mem�ria
*ptr = 1;

printf("\nPtr:%d", *ptr);

free(ptr); //Dealoca��o de mem�ria

*ptr = 5;

printf("\nPtr:%d", *ptr); //Pode ou n�o resultar no valor 5, pois o apontador agora est� a apontar para uma posi��o de mem�ria n�o reservada

////Opera��es aritm�ticas com Apontadores

////NOTA: de referir que os apontadores n�o s�o vari�veis como as outras. Eles n�o armazenam valores como as
///outras vari�veis, mas sim endere�os de mem�ria, ent�o n�o faz sentido a adi��o ou subtrac��o de apontadores por exemplo.
///As opera��es aritm�ticas com apontadores s�o diferentes das com vari�veis normais.

///NOTA: Os apontadores t�m poucas mas �teis opera��es

//Podemos atribuir um valor de um apontador a outro, se eles forem do mesmo tipo, a menos que sejam typecasted ou um deles void*

int kVar = 10;

int *addressOfKvar = &kVar;
int *anotherAddressOfKvar = NULL;

printf("\nAddress of Kvar: %p\n", addressOfKvar);
printf("\nAnother address of Kvar: %p\n", anotherAddressOfKvar);

anotherAddressOfKvar = addressOfKvar;//Valid

printf("\nAnother address of Kvar (after assignment): %p\n", anotherAddressOfKvar);

char *wrongAddressOfKvar = addressOfKvar;
printf("\nAnother address of Kvar (after assignment with char*): %p\n", wrongAddressOfKvar);

//////////////////////// NOTE: You can only add or subtract integers to pointers

int myArray []= {2, 1, 4, 34, 56, 123};

int *pointerToMyarray = &myArray[1];

printf("\nTamanho em bytes de um inteiro: %d\n", sizeof(int));
printf("\nPointer value before adding: %d\n", pointerToMyarray);
pointerToMyarray += 7;//NOTA IMPORTANTE: ao adicionarmos um valor ao apontador estamos a avan�ar em 7 posi��es de mem�ria (4 bytes cada por ser inteiro)
//e n�o a adicionar o valor 7 em si.

//pointerToMyarray *= 2;

printf("\nAdd value to the pointer:%d\n", pointerToMyarray);

printf("\n\n\n");

//3.  Subtraction and comparison of pointers is valid only if both are members of the same array.
//The subtraction of pointers gives the number of elements separating them.

int myNewArray[] = {2, 5,21, 1, 45, 23};

int sixthMultiple = 18;

int *pointer1 = &myNewArray[0];
int *pointer2 = &myNewArray[1];
int *pointer6 = &sixthMultiple;

printf("\nPointer1 value:%d\n", pointer1);
printf("\nPointer2 value:%d\n", pointer2);

/* Valid Expression */

 //if(pointer1 == pointer2) //O programa deveria estrar nesta condi��o pois pointer1 e pointer2 s�o do mesmo tipo, int*
    printf("\nComparison with subtraction: %d\n", (pointer2 - pointer1)); //O resultado � 1 pois s� existe uma posi��o de mem�ria de
                                                                        //diferen�a entre os dois apontadores

 ///// Invalid expression ////
 if(pointer1 == pointer6){ //Os dois apontadores n�o pertencem ao mesmo array
    pointer1 - pointer6;

}

//NOTE: 4.  We can assign or compare a pointer with NULL.

//B. Arrays and Strings

//In C, pointers and arrays have a strong relationship

//NOTA: o que podemos obter com arrayName[index] podemos obter com pointers e ainda mais r�pido na maior parte das vezes, por isso haver uma grande rela��o entre ambos

///////////////////////// 1-D Arrays /////////////////////////////////////////////

int arrayValues[5] = {21, 4, 6, 70, 67};

printf("\nResult using &arrayValues: %d\n", &arrayValues);
printf("Result using only arrayValues: %d\n", arrayValues);
printf("Result using &arrayValues[0]: %d\n", &arrayValues[0]); //NOTA: as tr�s express�es resultam no mesmo valor

//////// ************** MUITO IMPORTANTE ******************************************** ////////////////////////////////

//arrayValues e &arrayValues apontam para a posi��o inicial 0 do array. O pr�prio nome do array aponta para a posi��o
//inicial, para o elemento 0 do array. Por seu lado &arrayValues aponta para o array int completo de tamanho 5, come�ando no primeiro
//elemento do array por essa raz�o o valor ser igual a arrayValues e &arrayValues[0]. Por isso h� uma grande rela��o entre apontadores
//e arrays. Portanto, quando h� um incremento de 1 em &arrayValues, resulta num endere�o de 5 x 4 bytes = 20 bytes.


printf("\nIncrement by 1:\n");
printf("Using &arrayValues: %d\n", (&arrayValues + 1)); //Incrementa 5 x 4 bytes de mem�ria = 20 bytes
printf("Using arrayValues: %d\n", (arrayValues + 1)); //Incrementa 4 bytes, passando para a posi��o de mem�ria seguinte arrayValues[1]
printf("Using &arrayValues[0]: %d\n", (&arrayValues[0] + 1)); //Incrementa 4 bytes, passando para a posi��o de mem�ria seguinte arrayValues[1]


//Resumindo, arrayValues e &arrayValues[0] apontam para o elemento 0 do array, enquanto &arrayValues aponta para o array inteiro.

printf("\n************** Access the array elements: ***************\n");

//Forma convencional

printf("\nForma convencional\n");
for(int i = 0; i < 5; i++){
    printf("\nIndex: %d, memory position(address): %d, element value: %d\n", i, &arrayValues[i], arrayValues[i]);
}

//Usando apontadores que � muito mais r�pido

printf("\n\n**** Duas formas usando pointers ****\n");

for (int j = 0; j < 5; j++){
        printf("\nIndex: %d, memory position(address): %d, element value: %d\n", j, (arrayValues + j), *(arrayValues + j));
}

printf("\n\n");
for (int j = 0; j < 5; j++){
        printf("\nIndex: %d, memory position(address): %d, element value: %d\n", j, &arrayValues[j],*(&arrayValues[j]));
}


///NOTA MUITO IMPORTANTE: &arrayName[i] e arrayName[i] s�o o mesmo que arrayName + i e *(arrayName + i), respectivamente.

///2-D Arrays (28/10/2021)

}


////Linked  Lists

//Given a reference (pointer to pointer) to the head of a list
//and an int, inserts a new node on the front of the list

void push(struct Person** head_ref, char newID[], char newName[], int newAge, char newAddress[]){

printf("\nEntrei push 1!!!!\n");
//1. allocate node
struct Person* newNode = (struct Person*)malloc(sizeof(struct Person));

printf("\nEntrei push 2!!!!\n");

//2. Put in the data
strcpy(newNode->personID, newID);
strcpy(newNode->name,newName);
newNode->age = newAge;
strcpy(newNode->address,newAddress);

//3. Make next of new node as head

newNode->next = (*head_ref);

//4. Move the head to point to the new node
(*head_ref) = newNode;

}

//NOTA: Faltam aqui as outras 2 formas de inserir dados em uma lista (GeeksForGeeks)

/* Given a node prev_node, insert a new node after the given
prev_node */

//void insertAfter(){

//}

/////////////////////////////////////////////////////////
void printList(struct Person* p){ //Print content of linked list

        while (p != NULL)
        {
            printf("\nPerson ID: %s\n", p->personID);
            printf("Person Name: %s\n", p->name);
            printf("Person Age: %d\n", p->age);
            printf("Person Address: %s\n", p->address);
            p = p->next;
        }
}

//Search an element in a linked list by key

void searchElement(struct Person* ps, char id[]){

    //Initialize a node pointer, current = head.
    struct Person* pn = ps;

    //Do following while current is not NULL
    while(pn != NULL){

        if (strcmp(pn->personID, id) == 0){
            printf("\nPerson ID: %s\n", pn->personID);
            printf("Person Name: %s\n", pn->name);
            printf("Person Age: %d\n", pn->age);
            printf("Person Address: %s\n", pn->address);
            break;
        }else{
            pn = pn->next;
        }
    }

}

void getStr(char str[],size_t len)
{
	char buffer[MAXSTR];
	fgets(buffer,MAXSTR,stdin);
	buffer[strcspn(buffer,"\n")]='\0';

	if(strlen(buffer)<len)
		strcpy(str,buffer);
	else
	{
		strncpy(str,buffer,len-1);
		str[len-1]='\0';
	}
}

